# Your imports


def months_interval(start_date, end_date):
    #
    # Your implementation here.
    #
